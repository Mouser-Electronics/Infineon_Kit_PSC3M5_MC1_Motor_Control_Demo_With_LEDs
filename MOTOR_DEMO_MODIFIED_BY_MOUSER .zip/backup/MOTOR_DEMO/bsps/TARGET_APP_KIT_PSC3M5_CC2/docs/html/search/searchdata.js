var indexSectionsWithContent =
{
  0: "bcefklmpsw",
  1: "c",
  2: "s",
  3: "bceflpw",
  4: "kmp"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "variables",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Variables",
  3: "Modules",
  4: "Pages"
};

