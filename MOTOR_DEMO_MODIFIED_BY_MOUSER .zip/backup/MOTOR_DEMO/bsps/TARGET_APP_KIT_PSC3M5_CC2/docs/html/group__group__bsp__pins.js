var group__group__bsp__pins =
[
    [ "LED Pins", "group__group__bsp__pins__led.html", null ],
    [ "Button Pins", "group__group__bsp__pins__btn.html", null ],
    [ "Communication Pins", "group__group__bsp__pins__comm.html", null ],
    [ "WCO", "group__group__bsp__pins__wco.html", null ]
];