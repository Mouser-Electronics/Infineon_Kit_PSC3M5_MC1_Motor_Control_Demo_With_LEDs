/*******************************************************************************
 * File Name: cycfg_pins.h
 *
 * Description:
 * Pin configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.40.0
 * device-db 4.22.0.7873
 * motor-ctrl-lib 1.9.0.248
 * mtb-pdl-cat1 3.16.0.40964
 *
 *******************************************************************************
 * Copyright 2025 Cypress Semiconductor Corporation (an Infineon company) or
 * an affiliate of Cypress Semiconductor Corporation.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_PINS_H)
#define CYCFG_PINS_H

#include "cycfg_notices.h"
#include "cy_gpio.h"
#include "cycfg_routing.h"

#if defined (CY_USING_HAL)
#include "cyhal_hwmgr.h"
#endif /* defined (CY_USING_HAL) */

#if defined (CY_USING_HAL_LITE)
#include "cyhal_hw_types.h"
#endif /* defined (CY_USING_HAL_LITE) */

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#define CYBSP_WCO_OUT_ENABLED 1U
#define CYBSP_MIKROBUS_INT_ENABLED CYBSP_WCO_OUT_ENABLED
#define CYBSP_WCO_OUT_PORT GPIO_PRT0
#define CYBSP_MIKROBUS_INT_PORT CYBSP_WCO_OUT_PORT
#define CYBSP_WCO_OUT_PORT_NUM 0U
#define CYBSP_MIKROBUS_INT_PORT_NUM CYBSP_WCO_OUT_PORT_NUM
#define CYBSP_WCO_OUT_PIN 0U
#define CYBSP_MIKROBUS_INT_PIN CYBSP_WCO_OUT_PIN
#define CYBSP_WCO_OUT_NUM 0U
#define CYBSP_MIKROBUS_INT_NUM CYBSP_WCO_OUT_NUM
#define CYBSP_WCO_OUT_DRIVEMODE CY_GPIO_DM_ANALOG
#define CYBSP_MIKROBUS_INT_DRIVEMODE CYBSP_WCO_OUT_DRIVEMODE
#define CYBSP_WCO_OUT_INIT_DRIVESTATE 1
#define CYBSP_MIKROBUS_INT_INIT_DRIVESTATE CYBSP_WCO_OUT_INIT_DRIVESTATE
#ifndef ioss_0_port_0_pin_0_HSIOM
    #define ioss_0_port_0_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_WCO_OUT_HSIOM ioss_0_port_0_pin_0_HSIOM
#define CYBSP_MIKROBUS_INT_HSIOM CYBSP_WCO_OUT_HSIOM
#define CYBSP_WCO_OUT_IRQ ioss_interrupts_sec_gpio_0_IRQn
#define CYBSP_MIKROBUS_INT_IRQ CYBSP_WCO_OUT_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_WCO_OUT_HAL_PORT_PIN P0_0
#define CYBSP_MIKROBUS_INT_HAL_PORT_PIN CYBSP_WCO_OUT_HAL_PORT_PIN
#define CYBSP_WCO_OUT P0_0
#define CYBSP_MIKROBUS_INT CYBSP_WCO_OUT
#define CYBSP_WCO_OUT_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_MIKROBUS_INT_HAL_IRQ CYBSP_WCO_OUT_HAL_IRQ
#define CYBSP_WCO_OUT_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_MIKROBUS_INT_HAL_DIR CYBSP_WCO_OUT_HAL_DIR
#define CYBSP_WCO_OUT_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#define CYBSP_MIKROBUS_INT_HAL_DRIVEMODE CYBSP_WCO_OUT_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_WCO_IN_ENABLED 1U
#define CYBSP_MIKROBUS_PWM_ENABLED CYBSP_WCO_IN_ENABLED
#define CYBSP_WCO_IN_PORT GPIO_PRT0
#define CYBSP_MIKROBUS_PWM_PORT CYBSP_WCO_IN_PORT
#define CYBSP_WCO_IN_PORT_NUM 0U
#define CYBSP_MIKROBUS_PWM_PORT_NUM CYBSP_WCO_IN_PORT_NUM
#define CYBSP_WCO_IN_PIN 1U
#define CYBSP_MIKROBUS_PWM_PIN CYBSP_WCO_IN_PIN
#define CYBSP_WCO_IN_NUM 1U
#define CYBSP_MIKROBUS_PWM_NUM CYBSP_WCO_IN_NUM
#define CYBSP_WCO_IN_DRIVEMODE CY_GPIO_DM_ANALOG
#define CYBSP_MIKROBUS_PWM_DRIVEMODE CYBSP_WCO_IN_DRIVEMODE
#define CYBSP_WCO_IN_INIT_DRIVESTATE 1
#define CYBSP_MIKROBUS_PWM_INIT_DRIVESTATE CYBSP_WCO_IN_INIT_DRIVESTATE
#ifndef ioss_0_port_0_pin_1_HSIOM
    #define ioss_0_port_0_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_WCO_IN_HSIOM ioss_0_port_0_pin_1_HSIOM
#define CYBSP_MIKROBUS_PWM_HSIOM CYBSP_WCO_IN_HSIOM
#define CYBSP_WCO_IN_IRQ ioss_interrupts_sec_gpio_0_IRQn
#define CYBSP_MIKROBUS_PWM_IRQ CYBSP_WCO_IN_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_WCO_IN_HAL_PORT_PIN P0_1
#define CYBSP_MIKROBUS_PWM_HAL_PORT_PIN CYBSP_WCO_IN_HAL_PORT_PIN
#define CYBSP_WCO_IN P0_1
#define CYBSP_MIKROBUS_PWM CYBSP_WCO_IN
#define CYBSP_WCO_IN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_MIKROBUS_PWM_HAL_IRQ CYBSP_WCO_IN_HAL_IRQ
#define CYBSP_WCO_IN_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_MIKROBUS_PWM_HAL_DIR CYBSP_WCO_IN_HAL_DIR
#define CYBSP_WCO_IN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#define CYBSP_MIKROBUS_PWM_HAL_DRIVEMODE CYBSP_WCO_IN_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_ECO_IN_ENABLED 1U
#define CYBSP_ECO_IN_PORT GPIO_PRT1
#define CYBSP_ECO_IN_PORT_NUM 1U
#define CYBSP_ECO_IN_PIN 0U
#define CYBSP_ECO_IN_NUM 0U
#define CYBSP_ECO_IN_DRIVEMODE CY_GPIO_DM_ANALOG
#define CYBSP_ECO_IN_INIT_DRIVESTATE 1
#ifndef ioss_0_port_1_pin_0_HSIOM
    #define ioss_0_port_1_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_ECO_IN_HSIOM ioss_0_port_1_pin_0_HSIOM
#define CYBSP_ECO_IN_IRQ ioss_interrupts_sec_gpio_1_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_ECO_IN_HAL_PORT_PIN P1_0
#define CYBSP_ECO_IN P1_0
#define CYBSP_ECO_IN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_ECO_IN_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_ECO_IN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_ECO_OUT_ENABLED 1U
#define CYBSP_ECO_OUT_PORT GPIO_PRT1
#define CYBSP_ECO_OUT_PORT_NUM 1U
#define CYBSP_ECO_OUT_PIN 1U
#define CYBSP_ECO_OUT_NUM 1U
#define CYBSP_ECO_OUT_DRIVEMODE CY_GPIO_DM_ANALOG
#define CYBSP_ECO_OUT_INIT_DRIVESTATE 1
#ifndef ioss_0_port_1_pin_1_HSIOM
    #define ioss_0_port_1_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_ECO_OUT_HSIOM ioss_0_port_1_pin_1_HSIOM
#define CYBSP_ECO_OUT_IRQ ioss_interrupts_sec_gpio_1_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_ECO_OUT_HAL_PORT_PIN P1_1
#define CYBSP_ECO_OUT P1_1
#define CYBSP_ECO_OUT_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_ECO_OUT_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define CYBSP_ECO_OUT_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_SWDCK_ENABLED 1U
#define CYBSP_SWDCK_PORT GPIO_PRT1
#define CYBSP_SWDCK_PORT_NUM 1U
#define CYBSP_SWDCK_PIN 2U
#define CYBSP_SWDCK_NUM 2U
#define CYBSP_SWDCK_DRIVEMODE CY_GPIO_DM_PULLDOWN
#define CYBSP_SWDCK_INIT_DRIVESTATE 1
#ifndef ioss_0_port_1_pin_2_HSIOM
    #define ioss_0_port_1_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_SWDCK_HSIOM ioss_0_port_1_pin_2_HSIOM
#define CYBSP_SWDCK_IRQ ioss_interrupts_sec_gpio_1_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_SWDCK_HAL_PORT_PIN P1_2
#define CYBSP_SWDCK P1_2
#define CYBSP_SWDCK_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_SWDCK_HAL_DIR CYHAL_GPIO_DIR_BIDIRECTIONAL 
#define CYBSP_SWDCK_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_PULLDOWN
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_SWDIO_ENABLED 1U
#define CYBSP_SWDIO_PORT GPIO_PRT1
#define CYBSP_SWDIO_PORT_NUM 1U
#define CYBSP_SWDIO_PIN 3U
#define CYBSP_SWDIO_NUM 3U
#define CYBSP_SWDIO_DRIVEMODE CY_GPIO_DM_PULLUP
#define CYBSP_SWDIO_INIT_DRIVESTATE 1
#ifndef ioss_0_port_1_pin_3_HSIOM
    #define ioss_0_port_1_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_SWDIO_HSIOM ioss_0_port_1_pin_3_HSIOM
#define CYBSP_SWDIO_IRQ ioss_interrupts_sec_gpio_1_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_SWDIO_HAL_PORT_PIN P1_3
#define CYBSP_SWDIO P1_3
#define CYBSP_SWDIO_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_SWDIO_HAL_DIR CYHAL_GPIO_DIR_BIDIRECTIONAL 
#define CYBSP_SWDIO_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_PULLUP
#define CYBSP_TDI (P2_0)
#define CYBSP_TDO (P2_1)
#define CYBSP_DEBUG_UART_RX (P2_2)
#define CYBSP_MIKROBUS_UART_RX CYBSP_DEBUG_UART_RX
#define CYBSP_DEBUG_UART_TX (P2_3)
#define CYBSP_MIKROBUS_UART_TX CYBSP_DEBUG_UART_TX
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define PWMUH_ENABLED 1U
#define PWMUH_PORT GPIO_PRT4
#define PWMUH_PORT_NUM 4U
#define PWMUH_PIN 0U
#define PWMUH_NUM 0U
#define PWMUH_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define PWMUH_INIT_DRIVESTATE 0
#ifndef ioss_0_port_4_pin_0_HSIOM
    #define ioss_0_port_4_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define PWMUH_HSIOM ioss_0_port_4_pin_0_HSIOM
#define PWMUH_IRQ ioss_interrupts_sec_gpio_4_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define PWMUH_HAL_PORT_PIN P4_0
#define PWMUH P4_0
#define PWMUH_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define PWMUH_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define PWMUH_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define PWMUL_ENABLED 1U
#define PWMUL_PORT GPIO_PRT4
#define PWMUL_PORT_NUM 4U
#define PWMUL_PIN 1U
#define PWMUL_NUM 1U
#define PWMUL_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define PWMUL_INIT_DRIVESTATE 0
#ifndef ioss_0_port_4_pin_1_HSIOM
    #define ioss_0_port_4_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define PWMUL_HSIOM ioss_0_port_4_pin_1_HSIOM
#define PWMUL_IRQ ioss_interrupts_sec_gpio_4_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define PWMUL_HAL_PORT_PIN P4_1
#define PWMUL P4_1
#define PWMUL_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define PWMUL_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define PWMUL_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define PWMVH_ENABLED 1U
#define PWMVH_PORT GPIO_PRT4
#define PWMVH_PORT_NUM 4U
#define PWMVH_PIN 2U
#define PWMVH_NUM 2U
#define PWMVH_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define PWMVH_INIT_DRIVESTATE 0
#ifndef ioss_0_port_4_pin_2_HSIOM
    #define ioss_0_port_4_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define PWMVH_HSIOM ioss_0_port_4_pin_2_HSIOM
#define PWMVH_IRQ ioss_interrupts_sec_gpio_4_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define PWMVH_HAL_PORT_PIN P4_2
#define PWMVH P4_2
#define PWMVH_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define PWMVH_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define PWMVH_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define PWMVL_ENABLED 1U
#define PWMVL_PORT GPIO_PRT4
#define PWMVL_PORT_NUM 4U
#define PWMVL_PIN 3U
#define PWMVL_NUM 3U
#define PWMVL_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define PWMVL_INIT_DRIVESTATE 0
#ifndef ioss_0_port_4_pin_3_HSIOM
    #define ioss_0_port_4_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define PWMVL_HSIOM ioss_0_port_4_pin_3_HSIOM
#define PWMVL_IRQ ioss_interrupts_sec_gpio_4_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define PWMVL_HAL_PORT_PIN P4_3
#define PWMVL P4_3
#define PWMVL_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define PWMVL_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define PWMVL_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define PWMWH_ENABLED 1U
#define PWMWH_PORT GPIO_PRT4
#define PWMWH_PORT_NUM 4U
#define PWMWH_PIN 4U
#define PWMWH_NUM 4U
#define PWMWH_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define PWMWH_INIT_DRIVESTATE 0
#ifndef ioss_0_port_4_pin_4_HSIOM
    #define ioss_0_port_4_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define PWMWH_HSIOM ioss_0_port_4_pin_4_HSIOM
#define PWMWH_IRQ ioss_interrupts_sec_gpio_4_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define PWMWH_HAL_PORT_PIN P4_4
#define PWMWH P4_4
#define PWMWH_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define PWMWH_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define PWMWH_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define PWMWL_ENABLED 1U
#define PWMWL_PORT GPIO_PRT4
#define PWMWL_PORT_NUM 4U
#define PWMWL_PIN 5U
#define PWMWL_NUM 5U
#define PWMWL_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define PWMWL_INIT_DRIVESTATE 0
#ifndef ioss_0_port_4_pin_5_HSIOM
    #define ioss_0_port_4_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define PWMWL_HSIOM ioss_0_port_4_pin_5_HSIOM
#define PWMWL_IRQ ioss_interrupts_sec_gpio_4_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define PWMWL_HAL_PORT_PIN P4_5
#define PWMWL P4_5
#define PWMWL_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define PWMWL_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define PWMWL_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_USER_BTN_ENABLED 1U
#define N_DIR_PUSHBTN_ENABLED CYBSP_USER_BTN_ENABLED
#define CYBSP_USER_BTN_PORT GPIO_PRT4
#define N_DIR_PUSHBTN_PORT CYBSP_USER_BTN_PORT
#define CYBSP_USER_BTN_PORT_NUM 4U
#define N_DIR_PUSHBTN_PORT_NUM CYBSP_USER_BTN_PORT_NUM
#define CYBSP_USER_BTN_PIN 6U
#define N_DIR_PUSHBTN_PIN CYBSP_USER_BTN_PIN
#define CYBSP_USER_BTN_NUM 6U
#define N_DIR_PUSHBTN_NUM CYBSP_USER_BTN_NUM
#define CYBSP_USER_BTN_DRIVEMODE CY_GPIO_DM_HIGHZ
#define N_DIR_PUSHBTN_DRIVEMODE CYBSP_USER_BTN_DRIVEMODE
#define CYBSP_USER_BTN_INIT_DRIVESTATE 1
#define N_DIR_PUSHBTN_INIT_DRIVESTATE CYBSP_USER_BTN_INIT_DRIVESTATE
#ifndef ioss_0_port_4_pin_6_HSIOM
    #define ioss_0_port_4_pin_6_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_USER_BTN_HSIOM ioss_0_port_4_pin_6_HSIOM
#define N_DIR_PUSHBTN_HSIOM CYBSP_USER_BTN_HSIOM
#define CYBSP_USER_BTN_IRQ ioss_interrupts_sec_gpio_4_IRQn
#define N_DIR_PUSHBTN_IRQ CYBSP_USER_BTN_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_USER_BTN_HAL_PORT_PIN P4_6
#define N_DIR_PUSHBTN_HAL_PORT_PIN CYBSP_USER_BTN_HAL_PORT_PIN
#define CYBSP_USER_BTN P4_6
#define N_DIR_PUSHBTN CYBSP_USER_BTN
#define CYBSP_USER_BTN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define N_DIR_PUSHBTN_HAL_IRQ CYBSP_USER_BTN_HAL_IRQ
#define CYBSP_USER_BTN_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define N_DIR_PUSHBTN_HAL_DIR CYBSP_USER_BTN_HAL_DIR
#define CYBSP_USER_BTN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define N_DIR_PUSHBTN_HAL_DRIVEMODE CYBSP_USER_BTN_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define N_HALL_EN_ENABLED 1U
#define ENC_EN_ENABLED N_HALL_EN_ENABLED
#define N_HALL_EN_PORT GPIO_PRT4
#define ENC_EN_PORT N_HALL_EN_PORT
#define N_HALL_EN_PORT_NUM 4U
#define ENC_EN_PORT_NUM N_HALL_EN_PORT_NUM
#define N_HALL_EN_PIN 7U
#define ENC_EN_PIN N_HALL_EN_PIN
#define N_HALL_EN_NUM 7U
#define ENC_EN_NUM N_HALL_EN_NUM
#define N_HALL_EN_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define ENC_EN_DRIVEMODE N_HALL_EN_DRIVEMODE
#define N_HALL_EN_INIT_DRIVESTATE 0
#define ENC_EN_INIT_DRIVESTATE N_HALL_EN_INIT_DRIVESTATE
#ifndef ioss_0_port_4_pin_7_HSIOM
    #define ioss_0_port_4_pin_7_HSIOM HSIOM_SEL_GPIO
#endif
#define N_HALL_EN_HSIOM ioss_0_port_4_pin_7_HSIOM
#define ENC_EN_HSIOM N_HALL_EN_HSIOM
#define N_HALL_EN_IRQ ioss_interrupts_sec_gpio_4_IRQn
#define ENC_EN_IRQ N_HALL_EN_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define N_HALL_EN_HAL_PORT_PIN P4_7
#define ENC_EN_HAL_PORT_PIN N_HALL_EN_HAL_PORT_PIN
#define N_HALL_EN P4_7
#define ENC_EN N_HALL_EN
#define N_HALL_EN_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ENC_EN_HAL_IRQ N_HALL_EN_HAL_IRQ
#define N_HALL_EN_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define ENC_EN_HAL_DIR N_HALL_EN_HAL_DIR
#define N_HALL_EN_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define ENC_EN_HAL_DRIVEMODE N_HALL_EN_HAL_DRIVEMODE
#define CYBSP_MIKROBUS_SPI_MOSI (P5_0)
#define CYBSP_MIKROBUS_I2C_SDA CYBSP_MIKROBUS_SPI_MOSI
#define CYBSP_MIKROBUS_SPI_MISO (P5_1)
#define CYBSP_MIKROBUS_I2C_SCL CYBSP_MIKROBUS_SPI_MISO
#define CYBSP_MIKROBUS_SPI_CLK (P5_2)
#define CYBSP_MIKROBUS_SPI_CS (P5_3)
#define CYBSP_CAN_RX (P6_2)
#define CYBSP_CAN_TX (P6_3)
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define HALL_0_ENABLED 1U
#define ENC_A_ENABLED HALL_0_ENABLED
#define HALL_0_PORT GPIO_PRT7
#define ENC_A_PORT HALL_0_PORT
#define HALL_0_PORT_NUM 7U
#define ENC_A_PORT_NUM HALL_0_PORT_NUM
#define HALL_0_PIN 4U
#define ENC_A_PIN HALL_0_PIN
#define HALL_0_NUM 4U
#define ENC_A_NUM HALL_0_NUM
#define HALL_0_DRIVEMODE CY_GPIO_DM_HIGHZ
#define ENC_A_DRIVEMODE HALL_0_DRIVEMODE
#define HALL_0_INIT_DRIVESTATE 0
#define ENC_A_INIT_DRIVESTATE HALL_0_INIT_DRIVESTATE
#ifndef ioss_0_port_7_pin_4_HSIOM
    #define ioss_0_port_7_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define HALL_0_HSIOM ioss_0_port_7_pin_4_HSIOM
#define ENC_A_HSIOM HALL_0_HSIOM
#define HALL_0_IRQ ioss_interrupts_sec_gpio_7_IRQn
#define ENC_A_IRQ HALL_0_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define HALL_0_HAL_PORT_PIN P7_4
#define ENC_A_HAL_PORT_PIN HALL_0_HAL_PORT_PIN
#define HALL_0 P7_4
#define ENC_A HALL_0
#define HALL_0_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ENC_A_HAL_IRQ HALL_0_HAL_IRQ
#define HALL_0_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define ENC_A_HAL_DIR HALL_0_HAL_DIR
#define HALL_0_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define ENC_A_HAL_DRIVEMODE HALL_0_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define HALL_1_ENABLED 1U
#define ENC_B_ENABLED HALL_1_ENABLED
#define HALL_1_PORT GPIO_PRT7
#define ENC_B_PORT HALL_1_PORT
#define HALL_1_PORT_NUM 7U
#define ENC_B_PORT_NUM HALL_1_PORT_NUM
#define HALL_1_PIN 5U
#define ENC_B_PIN HALL_1_PIN
#define HALL_1_NUM 5U
#define ENC_B_NUM HALL_1_NUM
#define HALL_1_DRIVEMODE CY_GPIO_DM_HIGHZ
#define ENC_B_DRIVEMODE HALL_1_DRIVEMODE
#define HALL_1_INIT_DRIVESTATE 0
#define ENC_B_INIT_DRIVESTATE HALL_1_INIT_DRIVESTATE
#ifndef ioss_0_port_7_pin_5_HSIOM
    #define ioss_0_port_7_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define HALL_1_HSIOM ioss_0_port_7_pin_5_HSIOM
#define ENC_B_HSIOM HALL_1_HSIOM
#define HALL_1_IRQ ioss_interrupts_sec_gpio_7_IRQn
#define ENC_B_IRQ HALL_1_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define HALL_1_HAL_PORT_PIN P7_5
#define ENC_B_HAL_PORT_PIN HALL_1_HAL_PORT_PIN
#define HALL_1 P7_5
#define ENC_B HALL_1
#define HALL_1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ENC_B_HAL_IRQ HALL_1_HAL_IRQ
#define HALL_1_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define ENC_B_HAL_DIR HALL_1_HAL_DIR
#define HALL_1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define ENC_B_HAL_DRIVEMODE HALL_1_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define HALL_2_ENABLED 1U
#define ENC_Z_ENABLED HALL_2_ENABLED
#define HALL_2_PORT GPIO_PRT7
#define ENC_Z_PORT HALL_2_PORT
#define HALL_2_PORT_NUM 7U
#define ENC_Z_PORT_NUM HALL_2_PORT_NUM
#define HALL_2_PIN 6U
#define ENC_Z_PIN HALL_2_PIN
#define HALL_2_NUM 6U
#define ENC_Z_NUM HALL_2_NUM
#define HALL_2_DRIVEMODE CY_GPIO_DM_HIGHZ
#define ENC_Z_DRIVEMODE HALL_2_DRIVEMODE
#define HALL_2_INIT_DRIVESTATE 0
#define ENC_Z_INIT_DRIVESTATE HALL_2_INIT_DRIVESTATE
#ifndef ioss_0_port_7_pin_6_HSIOM
    #define ioss_0_port_7_pin_6_HSIOM HSIOM_SEL_GPIO
#endif
#define HALL_2_HSIOM ioss_0_port_7_pin_6_HSIOM
#define ENC_Z_HSIOM HALL_2_HSIOM
#define HALL_2_IRQ ioss_interrupts_sec_gpio_7_IRQn
#define ENC_Z_IRQ HALL_2_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define HALL_2_HAL_PORT_PIN P7_6
#define ENC_Z_HAL_PORT_PIN HALL_2_HAL_PORT_PIN
#define HALL_2 P7_6
#define ENC_Z HALL_2
#define HALL_2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define ENC_Z_HAL_IRQ HALL_2_HAL_IRQ
#define HALL_2_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define ENC_Z_HAL_DIR HALL_2_HAL_DIR
#define HALL_2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#define ENC_Z_HAL_DRIVEMODE HALL_2_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define N_FAULT_HW_ENABLED 1U
#define N_FAULT_HW_PORT GPIO_PRT8
#define N_FAULT_HW_PORT_NUM 8U
#define N_FAULT_HW_PIN 0U
#define N_FAULT_HW_NUM 0U
#define N_FAULT_HW_DRIVEMODE CY_GPIO_DM_HIGHZ
#define N_FAULT_HW_INIT_DRIVESTATE 1
#ifndef ioss_0_port_8_pin_0_HSIOM
    #define ioss_0_port_8_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define N_FAULT_HW_HSIOM ioss_0_port_8_pin_0_HSIOM
#define N_FAULT_HW_IRQ ioss_interrupts_sec_gpio_8_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define N_FAULT_HW_HAL_PORT_PIN P8_0
#define N_FAULT_HW P8_0
#define N_FAULT_HW_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define N_FAULT_HW_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#define N_FAULT_HW_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN4_ENABLED 1U
#define TEST_PIN4_PORT GPIO_PRT8
#define TEST_PIN4_PORT_NUM 8U
#define TEST_PIN4_PIN 2U
#define TEST_PIN4_NUM 2U
#define TEST_PIN4_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN4_INIT_DRIVESTATE 0
#ifndef ioss_0_port_8_pin_2_HSIOM
    #define ioss_0_port_8_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN4_HSIOM ioss_0_port_8_pin_2_HSIOM
#define TEST_PIN4_IRQ ioss_interrupts_sec_gpio_8_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN4_HAL_PORT_PIN P8_2
#define TEST_PIN4 P8_2
#define TEST_PIN4_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN4_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN4_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN5_ENABLED 1U
#define TEST_PIN5_PORT GPIO_PRT8
#define TEST_PIN5_PORT_NUM 8U
#define TEST_PIN5_PIN 3U
#define TEST_PIN5_NUM 3U
#define TEST_PIN5_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN5_INIT_DRIVESTATE 0
#ifndef ioss_0_port_8_pin_3_HSIOM
    #define ioss_0_port_8_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN5_HSIOM ioss_0_port_8_pin_3_HSIOM
#define TEST_PIN5_IRQ ioss_interrupts_sec_gpio_8_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN5_HAL_PORT_PIN P8_3
#define TEST_PIN5 P8_3
#define TEST_PIN5_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN5_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN5_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN6_ENABLED 1U
#define TEST_PIN6_PORT GPIO_PRT8
#define TEST_PIN6_PORT_NUM 8U
#define TEST_PIN6_PIN 4U
#define TEST_PIN6_NUM 4U
#define TEST_PIN6_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN6_INIT_DRIVESTATE 0
#ifndef ioss_0_port_8_pin_4_HSIOM
    #define ioss_0_port_8_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN6_HSIOM ioss_0_port_8_pin_4_HSIOM
#define TEST_PIN6_IRQ ioss_interrupts_sec_gpio_8_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN6_HAL_PORT_PIN P8_4
#define TEST_PIN6 P8_4
#define TEST_PIN6_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN6_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN6_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN7_ENABLED 1U
#define TEST_PIN7_PORT GPIO_PRT8
#define TEST_PIN7_PORT_NUM 8U
#define TEST_PIN7_PIN 5U
#define TEST_PIN7_NUM 5U
#define TEST_PIN7_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN7_INIT_DRIVESTATE 0
#ifndef ioss_0_port_8_pin_5_HSIOM
    #define ioss_0_port_8_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN7_HSIOM ioss_0_port_8_pin_5_HSIOM
#define TEST_PIN7_IRQ ioss_interrupts_sec_gpio_8_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN7_HAL_PORT_PIN P8_5
#define TEST_PIN7 P8_5
#define TEST_PIN7_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN7_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN7_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN0_ENABLED 1U
#define TEST_PIN0_PORT GPIO_PRT9
#define TEST_PIN0_PORT_NUM 9U
#define TEST_PIN0_PIN 0U
#define TEST_PIN0_NUM 0U
#define TEST_PIN0_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN0_INIT_DRIVESTATE 0
#ifndef ioss_0_port_9_pin_0_HSIOM
    #define ioss_0_port_9_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN0_HSIOM ioss_0_port_9_pin_0_HSIOM
#define TEST_PIN0_IRQ ioss_interrupts_sec_gpio_9_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN0_HAL_PORT_PIN P9_0
#define TEST_PIN0 P9_0
#define TEST_PIN0_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN0_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN0_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN1_ENABLED 1U
#define TEST_PIN1_PORT GPIO_PRT9
#define TEST_PIN1_PORT_NUM 9U
#define TEST_PIN1_PIN 1U
#define TEST_PIN1_NUM 1U
#define TEST_PIN1_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN1_INIT_DRIVESTATE 0
#ifndef ioss_0_port_9_pin_1_HSIOM
    #define ioss_0_port_9_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN1_HSIOM ioss_0_port_9_pin_1_HSIOM
#define TEST_PIN1_IRQ ioss_interrupts_sec_gpio_9_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN1_HAL_PORT_PIN P9_1
#define TEST_PIN1 P9_1
#define TEST_PIN1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN1_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN2_ENABLED 1U
#define TEST_PIN2_PORT GPIO_PRT9
#define TEST_PIN2_PORT_NUM 9U
#define TEST_PIN2_PIN 2U
#define TEST_PIN2_NUM 2U
#define TEST_PIN2_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN2_INIT_DRIVESTATE 0
#ifndef ioss_0_port_9_pin_2_HSIOM
    #define ioss_0_port_9_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN2_HSIOM ioss_0_port_9_pin_2_HSIOM
#define TEST_PIN2_IRQ ioss_interrupts_sec_gpio_9_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN2_HAL_PORT_PIN P9_2
#define TEST_PIN2 P9_2
#define TEST_PIN2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN2_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define TEST_PIN3_ENABLED 1U
#define TEST_PIN3_PORT GPIO_PRT9
#define TEST_PIN3_PORT_NUM 9U
#define TEST_PIN3_PIN 3U
#define TEST_PIN3_NUM 3U
#define TEST_PIN3_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define TEST_PIN3_INIT_DRIVESTATE 0
#ifndef ioss_0_port_9_pin_3_HSIOM
    #define ioss_0_port_9_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define TEST_PIN3_HSIOM ioss_0_port_9_pin_3_HSIOM
#define TEST_PIN3_IRQ ioss_interrupts_sec_gpio_9_IRQn

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define TEST_PIN3_HAL_PORT_PIN P9_3
#define TEST_PIN3 P9_3
#define TEST_PIN3_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define TEST_PIN3_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define TEST_PIN3_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_USER_LED_ENABLED 1U
#define CYBSP_USER_LED1_ENABLED CYBSP_USER_LED_ENABLED
#define DIR_LED_ENABLED CYBSP_USER_LED_ENABLED
#define CYBSP_USER_LED_PORT GPIO_PRT9
#define CYBSP_USER_LED1_PORT CYBSP_USER_LED_PORT
#define DIR_LED_PORT CYBSP_USER_LED_PORT
#define CYBSP_USER_LED_PORT_NUM 9U
#define CYBSP_USER_LED1_PORT_NUM CYBSP_USER_LED_PORT_NUM
#define DIR_LED_PORT_NUM CYBSP_USER_LED_PORT_NUM
#define CYBSP_USER_LED_PIN 4U
#define CYBSP_USER_LED1_PIN CYBSP_USER_LED_PIN
#define DIR_LED_PIN CYBSP_USER_LED_PIN
#define CYBSP_USER_LED_NUM 4U
#define CYBSP_USER_LED1_NUM CYBSP_USER_LED_NUM
#define DIR_LED_NUM CYBSP_USER_LED_NUM
#define CYBSP_USER_LED_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define CYBSP_USER_LED1_DRIVEMODE CYBSP_USER_LED_DRIVEMODE
#define DIR_LED_DRIVEMODE CYBSP_USER_LED_DRIVEMODE
#define CYBSP_USER_LED_INIT_DRIVESTATE 0
#define CYBSP_USER_LED1_INIT_DRIVESTATE CYBSP_USER_LED_INIT_DRIVESTATE
#define DIR_LED_INIT_DRIVESTATE CYBSP_USER_LED_INIT_DRIVESTATE
#ifndef ioss_0_port_9_pin_4_HSIOM
    #define ioss_0_port_9_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_USER_LED_HSIOM ioss_0_port_9_pin_4_HSIOM
#define CYBSP_USER_LED1_HSIOM CYBSP_USER_LED_HSIOM
#define DIR_LED_HSIOM CYBSP_USER_LED_HSIOM
#define CYBSP_USER_LED_IRQ ioss_interrupts_sec_gpio_9_IRQn
#define CYBSP_USER_LED1_IRQ CYBSP_USER_LED_IRQ
#define DIR_LED_IRQ CYBSP_USER_LED_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_USER_LED_HAL_PORT_PIN P9_4
#define CYBSP_USER_LED1_HAL_PORT_PIN CYBSP_USER_LED_HAL_PORT_PIN
#define DIR_LED_HAL_PORT_PIN CYBSP_USER_LED_HAL_PORT_PIN
#define CYBSP_USER_LED P9_4
#define CYBSP_USER_LED1 CYBSP_USER_LED
#define DIR_LED CYBSP_USER_LED
#define CYBSP_USER_LED_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define CYBSP_USER_LED1_HAL_IRQ CYBSP_USER_LED_HAL_IRQ
#define DIR_LED_HAL_IRQ CYBSP_USER_LED_HAL_IRQ
#define CYBSP_USER_LED_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define CYBSP_USER_LED1_HAL_DIR CYBSP_USER_LED_HAL_DIR
#define DIR_LED_HAL_DIR CYBSP_USER_LED_HAL_DIR
#define CYBSP_USER_LED_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define CYBSP_USER_LED1_HAL_DRIVEMODE CYBSP_USER_LED_HAL_DRIVEMODE
#define DIR_LED_HAL_DRIVEMODE CYBSP_USER_LED_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

#define CYBSP_USER_LED2_ENABLED 1U
#define FAULT_LED_ALL_ENABLED CYBSP_USER_LED2_ENABLED
#define CYBSP_USER_LED2_PORT GPIO_PRT9
#define FAULT_LED_ALL_PORT CYBSP_USER_LED2_PORT
#define CYBSP_USER_LED2_PORT_NUM 9U
#define FAULT_LED_ALL_PORT_NUM CYBSP_USER_LED2_PORT_NUM
#define CYBSP_USER_LED2_PIN 5U
#define FAULT_LED_ALL_PIN CYBSP_USER_LED2_PIN
#define CYBSP_USER_LED2_NUM 5U
#define FAULT_LED_ALL_NUM CYBSP_USER_LED2_NUM
#define CYBSP_USER_LED2_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define FAULT_LED_ALL_DRIVEMODE CYBSP_USER_LED2_DRIVEMODE
#define CYBSP_USER_LED2_INIT_DRIVESTATE 0
#define FAULT_LED_ALL_INIT_DRIVESTATE CYBSP_USER_LED2_INIT_DRIVESTATE
#ifndef ioss_0_port_9_pin_5_HSIOM
    #define ioss_0_port_9_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define CYBSP_USER_LED2_HSIOM ioss_0_port_9_pin_5_HSIOM
#define FAULT_LED_ALL_HSIOM CYBSP_USER_LED2_HSIOM
#define CYBSP_USER_LED2_IRQ ioss_interrupts_sec_gpio_9_IRQn
#define FAULT_LED_ALL_IRQ CYBSP_USER_LED2_IRQ

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
#define CYBSP_USER_LED2_HAL_PORT_PIN P9_5
#define FAULT_LED_ALL_HAL_PORT_PIN CYBSP_USER_LED2_HAL_PORT_PIN
#define CYBSP_USER_LED2 P9_5
#define FAULT_LED_ALL CYBSP_USER_LED2
#define CYBSP_USER_LED2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#define FAULT_LED_ALL_HAL_IRQ CYBSP_USER_LED2_HAL_IRQ
#define CYBSP_USER_LED2_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#define FAULT_LED_ALL_HAL_DIR CYBSP_USER_LED2_HAL_DIR
#define CYBSP_USER_LED2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#define FAULT_LED_ALL_HAL_DRIVEMODE CYBSP_USER_LED2_HAL_DRIVEMODE
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_WCO_OUT_config;

#define CYBSP_MIKROBUS_INT_config CYBSP_WCO_OUT_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_WCO_OUT_obj;
#define CYBSP_MIKROBUS_INT_obj CYBSP_WCO_OUT_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_WCO_IN_config;

#define CYBSP_MIKROBUS_PWM_config CYBSP_WCO_IN_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_WCO_IN_obj;
#define CYBSP_MIKROBUS_PWM_obj CYBSP_WCO_IN_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_ECO_IN_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_ECO_IN_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_ECO_OUT_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_ECO_OUT_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_SWDCK_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_SWDCK_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_SWDIO_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_SWDIO_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t PWMUH_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t PWMUH_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t PWMUL_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t PWMUL_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t PWMVH_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t PWMVH_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t PWMVL_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t PWMVL_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t PWMWH_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t PWMWH_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t PWMWL_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t PWMWL_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_USER_BTN_config;

#define N_DIR_PUSHBTN_config CYBSP_USER_BTN_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_USER_BTN_obj;
#define N_DIR_PUSHBTN_obj CYBSP_USER_BTN_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t N_HALL_EN_config;

#define ENC_EN_config N_HALL_EN_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t N_HALL_EN_obj;
#define ENC_EN_obj N_HALL_EN_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t HALL_0_config;

#define ENC_A_config HALL_0_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t HALL_0_obj;
#define ENC_A_obj HALL_0_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t HALL_1_config;

#define ENC_B_config HALL_1_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t HALL_1_obj;
#define ENC_B_obj HALL_1_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t HALL_2_config;

#define ENC_Z_config HALL_2_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t HALL_2_obj;
#define ENC_Z_obj HALL_2_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t N_FAULT_HW_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t N_FAULT_HW_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN4_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN4_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN5_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN5_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN6_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN6_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN7_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN7_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN0_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN0_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN1_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN1_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN2_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN2_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t TEST_PIN3_config;

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t TEST_PIN3_obj;
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_USER_LED_config;

#define CYBSP_USER_LED1_config CYBSP_USER_LED_config
#define DIR_LED_config CYBSP_USER_LED_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_USER_LED_obj;
#define CYBSP_USER_LED1_obj CYBSP_USER_LED_obj
#define DIR_LED_obj CYBSP_USER_LED_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

extern const cy_stc_gpio_pin_config_t CYBSP_USER_LED2_config;

#define FAULT_LED_ALL_config CYBSP_USER_LED2_config

#if defined (CY_USING_HAL) || (CY_USING_HAL_LITE)
extern const cyhal_resource_inst_t CYBSP_USER_LED2_obj;
#define FAULT_LED_ALL_obj CYBSP_USER_LED2_obj
#endif /* defined (CY_USING_HAL) || (CY_USING_HAL_LITE) */

void init_cycfg_pins(void);
void reserve_cycfg_pins(void);

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_PINS_H */
