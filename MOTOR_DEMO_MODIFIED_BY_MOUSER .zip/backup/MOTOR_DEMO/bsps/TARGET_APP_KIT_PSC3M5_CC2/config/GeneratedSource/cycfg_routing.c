/*******************************************************************************
 * File Name: cycfg_routing.c
 *
 * Description:
 * Establishes all necessary connections between hardware elements.
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.40.0
 * device-db 4.22.0.7873
 * motor-ctrl-lib 1.9.0.248
 * mtb-pdl-cat1 3.16.0.40964
 *
 *******************************************************************************
 * Copyright 2025 Cypress Semiconductor Corporation (an Infineon company) or
 * an affiliate of Cypress Semiconductor Corporation.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#include "cycfg_routing.h"
#include "cy_trigmux.h"
#include "stdbool.h"
#include "cy_device_headers.h"

void init_cycfg_routing(void)
{
    Cy_TrigMux_Connect(TRIG_IN_MUX_0_PASS_PULSE0, TRIG_OUT_MUX_0_PDMA0_TR_IN0, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_0_PASS_PULSE1, TRIG_OUT_MUX_0_PDMA0_TR_IN1, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_10_TCPWM0_GRP0_OUT1_0, TRIG_OUT_MUX_10_TCPWM0_TR_IN11, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_10_TCPWM0_GRP1_OUT1_3, TRIG_OUT_MUX_10_TCPWM0_TR_IN10, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_10_TCPWM0_GRP1_OUT1_5, TRIG_OUT_MUX_10_TCPWM0_TR_IN9, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_10_TCPWM0_MOTIF_TR_OUT0, TRIG_OUT_MUX_10_TCPWM0_TR_IN8, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_10_TCPWM0_MOTIF_TR_OUT1, TRIG_OUT_MUX_10_TCPWM0_TR_IN12, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_10_TCPWM0_MOTIF_TR_OUT2, TRIG_OUT_MUX_10_TCPWM0_TR_IN13, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_13_HSIOM_TR_OUT34, TRIG_OUT_MUX_13_TCPWM0_MOTIF_TR_IN0, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_13_HSIOM_TR_OUT35, TRIG_OUT_MUX_13_TCPWM0_MOTIF_TR_IN1, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_14_TCPWM0_GRP1_OUT1_4, TRIG_OUT_MUX_14_PASS_TR_A_IN0, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_14_TCPWM0_GRP1_OUT1_5, TRIG_OUT_MUX_14_PASS_TR_A_IN1, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP0_LINE_0, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT43, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_256, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT15, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_257, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT17, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_258, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT19, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_259, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT42, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_260, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT40, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_261, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT41, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_COMPL_256, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT14, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_COMPL_257, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT16, false, TRIGGER_TYPE_LEVEL);
    Cy_TrigMux_Connect(TRIG_IN_MUX_2_TCPWM0_GRP1_LINE_COMPL_258, TRIG_OUT_MUX_2_HSIOM_TR_IO_OUTPUT18, false, TRIGGER_TYPE_LEVEL);
}
