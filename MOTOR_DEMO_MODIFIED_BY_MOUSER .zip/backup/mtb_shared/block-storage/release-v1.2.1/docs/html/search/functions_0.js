var searchData=
[
  ['mtb_5fblock_5fstorage_5fnvm_5fcreate_0',['mtb_block_storage_nvm_create',['../group__group__block__storage.html#gaf015526bd6a314dbfd78e2d12ad0533d',1,'mtb_block_storage_nvm_create(mtb_block_storage_t *bsd):&#160;mtb_block_storage_nvm.c'],['../group__group__block__storage.html#gaf015526bd6a314dbfd78e2d12ad0533d',1,'mtb_block_storage_nvm_create(mtb_block_storage_t *bsd):&#160;mtb_block_storage_nvm.c']]]
];
