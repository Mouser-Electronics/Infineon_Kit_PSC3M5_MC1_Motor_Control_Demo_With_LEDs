var indexSectionsWithContent =
{
  0: "bcegimpr",
  1: "m",
  2: "m",
  3: "cegipr",
  4: "m",
  5: "b",
  6: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Modules",
  6: "Pages"
};

