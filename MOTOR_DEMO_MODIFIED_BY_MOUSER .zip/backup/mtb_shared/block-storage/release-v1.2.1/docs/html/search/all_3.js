var searchData=
[
  ['get_5ferase_5fsize_0',['get_erase_size',['../group__group__block__storage.html#a55cbb7162d29c1d87ee0f1b011f9f3fa',1,'mtb_block_storage_t']]],
  ['get_5ferase_5fvalue_1',['get_erase_value',['../group__group__block__storage.html#a8bf6f9e001d413599e168cf2e3a215bc',1,'mtb_block_storage_t']]],
  ['get_5fprogram_5fsize_2',['get_program_size',['../group__group__block__storage.html#a04052bfa9b52af3b3d5668768cebd98b',1,'mtb_block_storage_t']]],
  ['get_5fread_5fsize_3',['get_read_size',['../group__group__block__storage.html#aac42f1e18d6b91ebe29cd767394d4fd7',1,'mtb_block_storage_t']]]
];
