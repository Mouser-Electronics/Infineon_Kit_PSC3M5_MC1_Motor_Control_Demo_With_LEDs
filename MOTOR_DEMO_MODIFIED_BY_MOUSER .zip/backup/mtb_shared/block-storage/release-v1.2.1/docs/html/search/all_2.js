var searchData=
[
  ['erase_0',['erase',['../group__group__block__storage.html#a1ff632b7d402bc19284f3bc3d55f3ae2',1,'mtb_block_storage_t']]],
  ['erase_5fnb_1',['erase_nb',['../group__group__block__storage.html#a9f217459f09f047d7e10774a3be72285',1,'mtb_block_storage_t']]]
];
