var indexSectionsWithContent =
{
  0: "_cp",
  1: "_",
  2: "p",
  3: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Variables",
  3: "Pages"
};

