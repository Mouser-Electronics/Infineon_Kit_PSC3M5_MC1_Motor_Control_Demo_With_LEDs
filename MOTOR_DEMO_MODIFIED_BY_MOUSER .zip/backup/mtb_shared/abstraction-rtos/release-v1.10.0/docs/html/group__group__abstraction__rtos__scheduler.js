var group__group__abstraction__rtos__scheduler =
[
    [ "cy_rtos_scheduler_suspend", "group__group__abstraction__rtos__scheduler.html#ga61f383c18398803438e76f280e2ba003", null ],
    [ "cy_rtos_scheduler_resume", "group__group__abstraction__rtos__scheduler.html#ga9e704925c79ff121e69f3f96b810b41f", null ]
];