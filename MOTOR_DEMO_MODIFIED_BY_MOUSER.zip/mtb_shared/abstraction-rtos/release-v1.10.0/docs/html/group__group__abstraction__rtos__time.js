var group__group__abstraction__rtos__time =
[
    [ "cy_rtos_get_time", "group__group__abstraction__rtos__time.html#ga15de185db07e4563b8d93b37ac941c51", null ],
    [ "cy_rtos_time_get", "group__group__abstraction__rtos__time.html#ga50f9ef2bbd3c518e0bf43ee14085e8bc", null ],
    [ "cy_rtos_delay_milliseconds", "group__group__abstraction__rtos__time.html#gaa33d9f3026f722ac92950c6215e4283a", null ]
];