var searchData=
[
  ['is_5ferase_5frequired_0',['is_erase_required',['../group__group__block__storage.html#a4f762c38ad091387fd890f22e68eb4a0',1,'mtb_block_storage_t']]],
  ['is_5fin_5frange_1',['is_in_range',['../group__group__block__storage.html#abc06bc9f2b64958d64de33100854fcb0',1,'mtb_block_storage_t']]]
];
