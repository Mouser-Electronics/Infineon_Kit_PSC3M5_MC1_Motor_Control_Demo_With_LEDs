var searchData=
[
  ['placeholder_0',['placeholder',['../struct__reent.html#a46236a052fb2e7b488dc29c80d153fd5',1,'_reent']]],
  ['ptr_1',['ptr',['../struct__reent.html#a6d4df0beb1a24c1ffe91e2de8e665003',1,'_reent']]]
];
